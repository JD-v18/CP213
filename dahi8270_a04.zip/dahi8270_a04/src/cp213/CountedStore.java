package cp213;

/**
 * Stores a value and an occurrence count for that value. The value must be
 * Comparable so that it can be compared and sorted against other values of the
 * same type.
 *
 * @author Jidaan Dahiya 211738270 dahi8270@mylaurier.ca
 * @version 2022-05-12
 */
public class CountedStore<T extends Comparable<T>> implements Comparable<CountedStore<T>> {

    // Attributes.
    private int count = 0; // store count
    private T store = null; // store

    /**
     * Copy constructor.
     *
     * @param source Another CountedStore object.
     */
    public CountedStore(final CountedStore<T> source) {
	this.store = source.store;
	this.count = source.count;
    }

    /**
     * Constructor for key version of object. (store count defaults to 0)
     *
     * @param store The store to be counted.
     */
    public CountedStore(final T store) {
	this.store = store;
    }

    /**
     * Constructor.
     *
     * @param store The store to be counted.
     * @param count The store count.
     */
    public CountedStore(final T store, final int count) {
	this.store = store;
	this.count = count;
    }

    /**
     * Comparison method for store values. Compares only the stored values, counts
     * are ignored. Returns:
     * <ul>
     * <li>0 if this equals target</li>
     * <li>&lt; 0 if this precedes target</li>
     * <li>&gt; 0 if this follows target</li>
     * </ul>
     *
     * @param target CountedStore object to compare against.
     * @return Comparison result.
     */
    @Override
    public int compareTo(CountedStore<T> target) {
	return this.store.compareTo(target.store);
    }

    /**
     * Decrements the store count.
     */
    public void decrementCount() {
	this.count--;
    }

    /**
     * Returns this store count.
     *
     * @return this store count.
     */
    public int getCount() {
	return this.count;
    }

    /**
     * Returns this store.
     *
     * @return this store.
     */
    public T getStore() {
	return this.store;
    }

    /**
     * Increments the store count.
     */
    public void incrementCount() {
	this.count++;
    }

    /**
     * Sets the store count.
     *
     * @param count the new store count.
     */
    public void setCount(final int count) {
	this.count = count;
	return;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
	return String.format("{%s: %d}", this.store.toString(), this.count);
    }

}
