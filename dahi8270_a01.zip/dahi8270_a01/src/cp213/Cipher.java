package cp213;

/**
 * @author Jidaan Dahiya 211738270
 * @version 2022-01-08
 */
public class Cipher {
    // Constants
    public static final String ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; // All alphabets in order
    public static final int ALPHA_LENGTH = ALPHA.length(); // Length of ALPHA

    /**
     * Encipher a string using a shift cipher. Each letter is replaced by a letter
     * 'n' letters to the right of the original. Thus for example, all shift values
     * evenly divisible by 26 (the length of the English alphabet) replace a letter
     * with itself. Non-letters are left unchanged.
     *
     * @param s string to encipher
     * @param n the number of letters to shift
     * @return the enciphered string
     */
    public static String shift(final String s, final int n) {
    String cipher = "";
    for (int i = 0; i < s.length(); i++) {
    	cipher += ALPHA.charAt(( (ALPHA.indexOf((s.charAt(i))) ) + n) % 26);
    }
    return cipher;
    }

    /**
     * Encipher a string using the letter positions in ciphertext. Each letter is
     * replaced by the letter in the same ordinal position in the ciphertext.
     * Non-letters are left unchanged. Ex:
     *
     * <pre>
    Alphabet:   ABCDEFGHIJKLMNOPQRSTUVWXYZ
    Ciphertext: AVIBROWNZCEFGHJKLMPQSTUXYD
     * </pre>
     *
     * A is replaced by A, B by V, C by I, D by B, E by R, and so on. Non-letters
     * are ignored.
     *
     * @param s          string to encipher
     * @param ciphertext ciphertext alphabet
     * @return the enciphered string
     */
    public static String substitute(final String s, final String ciphertext) {
    String subs = "";
    for (int i = 0; i < s.length(); i++) {
    	int index = ALPHA.indexOf((s.charAt(i)));
    	subs += ciphertext.charAt(index);
    }
	return subs;
    }

}
