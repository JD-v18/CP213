package cp213;

/**
 * @author Jidaan Dahiya 211738270
 * @version 2022-01-08
 */
public class Strings {
    // Constants
    public static final String VOWELS = "aeiouAEIOU"; //Vowels 

    /**
     * Determines if string is a "palindrome": a word, verse, or sentence (such as "Able
     * was I ere I saw Elba") that reads the same backward or forward. Ignores case,
     * spaces, digits, and punctuation in the string parameter s.
     *
     * @param string a string
     * @return true if string is a palindrome, false otherwise
     */
    public static boolean isPalindrome(final String string) {
    Boolean palindrome = true;
    String str = "";
    for (int i = 0; i<string.length(); i++) {
    	if (Character.isLetter(string.charAt(i))) {
    		str = str + Character.toLowerCase(string.charAt(i));
    	}
    }
    int i = 0;
    int j = str.length() - 1;
    while (i < j) {
    	if (str.charAt(i) != str.charAt(j)) {
	    	palindrome = false;
    	}
    	i++;
    	j--;
    }
	return palindrome;
    }

    /**
     * Determines if name is a valid Java variable name. Variables names must start
     * with a letter or an underscore, but cannot be an underscore alone. The rest
     * of the variable name may consist of letters, numbers and underscores.
     *
     * @param name a string to test as a Java variable name
     * @return true if name is a valid Java variable name, false otherwise
     */
    public static boolean isValid(final String name) {
    Boolean valid = true;
    if (!Character.isJavaIdentifierStart(name.charAt(0))) {
    	valid = false;
    }
    int i = 1;
    while (i < name.length() && valid) {
    	if (!Character.isJavaIdentifierPart(name.charAt(i))) {
    		valid = false;
    	}
    	i++;
    }
    return valid;
    }

    /**
     * Converts a word to Pig Latin. The conversion is:
     * <ul>
     * <li>if a word begins with a vowel, add "way" to the end of the word.</li>
     * <li>if the word begins with consonants, move the leading consonants to the
     * end of the word and add "ay" to the end of that. "y" is treated as a
     * consonant if it is the first character in the word, and as a vowel for
     * anywhere else in the word.</li>
     * </ul>
     * Preserve the case of the word - i.e. if the first character of word is
     * upper-case, then the new first character should also be upper case.
     *
     * @param word The string to convert to Pig Latin
     * @return the Pig Latin version of word
     */
    public static String pigLatin(String word) {
    String latin = "";
    // Checks case of first character
    Boolean first_upper = false;
    if (Character.isUpperCase(word.charAt(0))) {
    	first_upper = true;
    	word = word.toLowerCase();
    }
    // Checks condition to add required prefix
    if (VOWELS.indexOf(word.charAt(0)) != -1) { //|| word.charAt(0) == 'y'
    	latin = word + "way";
    }
    else {
    	latin = word.substring(1,word.length()) + word.charAt(0) + "ay";
    }
    // Changes the case of word according to first character of original word.
    if (first_upper) {
    	latin = Character.toUpperCase(latin.charAt(0)) + latin.substring(1,latin.length());
    }
    return latin;
    }

}


// Extra code for palindrome
//String reverse_str = "";
//for (int j = str.length()-1; j >= 0; j--) {
//	reverse_str += str.charAt(j);
//}
//int k = 0;
//while ((k < str.length()) && palindrome) {
//	if (str.charAt(k) != reverse_str.charAt(k)) {
//		palindrome = false;
//	}
//	k++;
//}
