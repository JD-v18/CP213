package cp213;

import java.io.PrintStream;
import java.util.Scanner;

/**
 * @author Jidaan Dahiya 211738270
 * @version 2022-01-08
 */
public class SerialNumber {

    /**
     * Determines if a string contains all digits.
     *
     * @param str The string to test.
     * @return true if str is all digits, false otherwise.
     */
    public static boolean allDigits(final String str) {
    Boolean digits = true;
    int i = 0;
    while (i < str.length() && digits) {
    	if (!Character.isDigit(str.charAt(i))) {
    		digits = false;
    	}
    	i++;
    }
	return digits;
    }

    /**
     * Determines if a string is a good serial number. Good serial numbers are of
     * the form 'SN/nnnn-nnn', where 'n' is a digit.
     *
     * @param sn The serial number to test.
     * @return true if the serial number is valid in form, false otherwise.
     */
    public static boolean validSn(final String sn) {
    Boolean valid = sn.matches("[A-Z]{2}[/][0-9]{4}[-][0-9]{3}");
	return valid;
    }

    /**
     * Evaluates serial numbers from a file. Writes valid serial numbers to
     * good_sns, and invalid serial numbers to bad_sns.
     *
     * @param fileIn  a file already open for reading
     * @param goodSns a file already open for writing
     * @param badSns  a file already open for writing
     */
    public static void validSnFile(final Scanner fileIn, final PrintStream goodSns, final PrintStream badSns) {
    String str = "";
    while (fileIn.hasNextLine()) {
    	str = fileIn.nextLine();
    	if (SerialNumber.validSn(str)) {
    		goodSns.println(str);
	    }
	    else {
	    	badSns.println(str);
	    }
    }
    fileIn.close();
    goodSns.close();
    badSns.close();
	return;
    }

}
