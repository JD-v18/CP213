package cp213;
import java.io.File;
import java.util.Scanner;

/**
 * Class to demonstrate the use of Scanner with a keyboard and File objects.
 *
 * @author your name here
 * @version 2022-01-08
 */
public class ScannerTest {
	
	
	public static void main(String args[]) {
		try {
			File file = new File("src/cp213/ScannerTest.java");
			Scanner source = new Scanner(file);
		} catch (Exception e) {
			System.out.println("File does not exist.");
		}
		Scanner keyboard = new Scanner(System.in);
	}

    /**
     * Count lines in the scanned file.
     *
     * @param source Scanner to process
     * @return number of lines in scanned file
     */
    public static int countLines(final Scanner source) 
    {
		int count = 0;
		while (source.hasNextLine())
		{
			source.nextLine();
			count++;
		}
		return count;
    }

    /**
     * Count tokens in the scanned object.
     *
     * @param source Scanner to process
     * @return number of tokens in scanned object
     */
    public static int countTokens(final Scanner source) 
    {
    	int tokens = 0;
    	while (source.hasNext())
    	{
    		source.next();
    		tokens++;
    	}
	return tokens;
    }

    /**
     * Ask for and total integers from the keyboard.
     *
     * @param keyboard Scanner to process
     * @return total of positive integers entered from keyboard
     */
    public static int readNumbers(final Scanner keyboard) 
    {
		int total = 0;
		boolean q_check = true;
		System.out.println("Enter a series of integers. Press 'q' to quit:");
		
		
		while (q_check)
		{
			if (keyboard.hasNextInt())
			{
				total += keyboard.nextInt();
			}
			else if (keyboard.hasNext())
			{
				String text = keyboard.next();
				if (text.equals("q"))
				{
					q_check = false;
				}
				else
				{
					System.out.println("'"+ text +"' is not an integer or 'q'.");
				}
			}
		}
		keyboard.close();	
		return total;
    }
}
