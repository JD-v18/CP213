package cp213;

import java.time.LocalDate;

/**
 * Student class definition.
 *
 * @author your name here
 * @version 2022-01-17
 */
public class Student implements Comparable<Student> {

    // Attributes
    private LocalDate birthDate = null;
    private String forename = "";
    private int id = 0;
    private String surname = "";

    /**
     * Instantiates a Student object.
     *
     * @param id        student ID number
     * @param surname   student surname
     * @param forename  name of forename
     * @param birthDate birthDate in 'YYYY-MM-DD' format
     */
    public Student(final int id, final String surname, final String forename, final LocalDate birthDate) {
    this.id = id;
    this.surname = surname;
    this.forename = forename;
    this.birthDate = birthDate;
    return;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString() Creates a formatted string of student data.
     */
    @Override
    public String toString() {
	String string = "";
	string += "Name:      " + surname + ", " + forename + "\n" + "ID:        " + id + "\n" + "Birthdate: " + birthDate;
	return string;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(final Student target) {
	int result = 0;
	if (this.surname.compareTo(target.surname) > 0) {
		result = 1;
	}
	else if (this.surname.compareTo(target.surname) < 0) {
		result = -1;
	}
	else {
		if (this.forename.compareTo(target.forename) > 0) {
			result = 1;
		}
		else if (this.forename.compareTo(target.forename) < 0) {
			result = -1;
		}
		else {
			if (this.id > target.id) {
				result = 1;
			}
			else if (this.id < target.id) {
				result = -1;
			}
			else {
				result = 0;
			}
		}
	}
	return result;
    }
    
    
    // setters defined here
    /**
     * Setter for student id
     * @param id student ID number
     */
    public void setId(int id) {
       this.id = id;
    }
    /**
     * Setter for student surname
     * @param surname Student Surname
     */
    public void setSurname(String surname) {
       this.surname = surname;
    }
    /**
     * Setter for student forename
     * @param forename Student Forename
     */
    public void setForename(String forename) {
       this.forename = forename;
    }
    /**
     * Setter for student birth date
     * @param birthDate Birth Date of Student
     */
    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }
    
    // getters defined here
    /**
     * Getter for student id
     * @return id student ID number
     */
    public int getId() {
        return this.id;
    }
    /**
     * Getter for student surname
     * @return surname Student Surname
     */
    public String getSurname() {
        return this.surname;
    }
    /**
     * Getter for student forename
     * @return forename Student Forename
     */
    public String getForename() {
        return this.forename;
    }
    /**
     * Getter for student birthdate
     * @return birthDate Birth Date of Student
     */
    public LocalDate getBirthDate() {
        return this.birthDate;
    }

}
