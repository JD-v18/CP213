package cp213;

/**
 * Inherited class in simple example of inheritance / polymorphism.
 *
 * @author Jidaan Dahiya 211738270 dahi8270@mylaurier.ca
 * @version 2022-02-25
 */
public class CAS extends Professor {

    private String term;
    
    /**
     * CAS constructor
     *
     * @param lastName    Student last name (surname): defined in Person
     * @param firstName   Student first name (given name): defined in Person
     * @param department  Department name
     * @param term        Term number
     */
    public CAS(final String lastName, final String firstName, final String department, final String term) {
    	super(lastName, firstName, department);
    	this.term = term;
    }
    
    /**
     * Getter for term.
     *
     * @return this.term
     */
    public String getTerm() {
    	return this.term;
    }
    
    /**
     * Creates formatted string version of CAS.
     */
    @Override
    public String toString() {
    	String output = super.toString() + "\n" + "Term: " + this.term;
    	return output;
    }

}
